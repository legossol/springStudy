package com.example.testate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestateApplicationTests {

	@Test
	void contextLoads() {
	}

}
